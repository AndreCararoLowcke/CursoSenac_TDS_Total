package uc9ativ2jframe;

//import menuPrincipal.menuPrincipal;

public class UC9ativ2Jframe {

    public static void main(String[] args) {
        menuPrincipal mp = new menuPrincipal();
        mp.setVisible(true);
    }
    
}
