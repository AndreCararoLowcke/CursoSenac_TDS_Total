
package classes;

public interface Imposto {

    double calcularImposto();

    String getDescricao();
}
