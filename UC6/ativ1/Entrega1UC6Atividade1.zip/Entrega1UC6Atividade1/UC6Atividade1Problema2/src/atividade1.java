

import problema2.CodigoProblema2;

public class atividade1 {

    public static void main(String[] args) {
        // TODO code application logic here
        CodigoProblema2 locacao = new CodigoProblema2("Maria",20,"João",60);
        System.out.println(locacao.getFrase());
    }
    
}
